package com.example.demo.entity;

import java.util.List;

import jakarta.persistence.ManyToMany;

public class StudentMTMBi {
	@ManyToMany(mappedBy = "students")
    private List<CourseMTMBi> courses;
}
