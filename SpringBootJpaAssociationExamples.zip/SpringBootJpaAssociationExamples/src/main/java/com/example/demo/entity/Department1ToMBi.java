package com.example.demo.entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Department1ToMBi {
	@Id
	private int dId;
 
    @OneToMany(mappedBy = "department")
    private List<Employee1ToMBi> employees;
 
}
 
