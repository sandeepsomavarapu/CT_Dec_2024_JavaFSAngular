package com.pdw.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("one-one");
		EntityManager em = factory.createEntityManager();
	
		// Employee add=em.find(Employee.class, 1); em.remove(add);

//		Address ad1 = new Address();
//		ad1.setHno(1234);
//		ad1.setColony("DLSN");
//		ad1.setCity("TG");
//	//	em.persist(ad1); // check your employee class first
//		Employee e = new Employee();
//		e.setEid(2);
//		e.setEname("NARESH");
//		e.setEsal(20000);
//		e.setAdd(ad1);
//		em.persist(e);

		Employee emp = em.find(Employee.class,2);
	//	System.out.println(emp.getEname());
//		System.out.println("With Eager");
//		System.out.println(emp.getAdd());

		
		em.close();
		factory.close();
	}
}