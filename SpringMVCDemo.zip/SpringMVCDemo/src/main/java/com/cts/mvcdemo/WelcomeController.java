package com.cts.mvcdemo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class WelcomeController {
	@RequestMapping("/welcome")
	public String message()
	{
		return "home";
		
	}
	@RequestMapping("/login")
	public String loginCheck(HttpServletRequest request,HttpServletResponse response,Model model)
	{
		String username=request.getParameter("uname");
		String password=request.getParameter("pass");
		System.out.println(username +" "+password);
		if(username.equals("cts") && password.equals("cts@123"))
		{
			model.addAttribute("uname", username);
			return "home";
		}
		else
		{
			model.addAttribute("errormsg", "Username/Password Mismatch");
			return "error";
		}
	}
}
