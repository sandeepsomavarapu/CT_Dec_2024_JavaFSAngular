package com.kpmg.springcore;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan("com.kpmg.springcore")
@PropertySource("app.properties")
public class AppConfig {
	@Bean("alternateMS")
	public MessageSender getMsBean() {
		System.out.println("done");
		MessageSender ms=new MessageSender();
		ms.setMmsCharge(4.2f);
		ms.setSmsCharge(5.5f);
		return ms;
	}

}
